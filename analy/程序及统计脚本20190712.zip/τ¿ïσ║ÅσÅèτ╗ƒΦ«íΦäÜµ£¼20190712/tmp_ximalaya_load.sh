#!/bin/bash

#喜马拉雅点击提取脚本

for ((day=20190701;day<=20190707;day++)) 
do
      if [ $day == 20190701 ]
              then 
              hive -e"
              drop table if exists tmp_user_con_out_t1;
              create table tmp_user_con_out_t1 as
              select       pt_days,
                           device_number,
                           case when url_host in ('mobwsa.ximalaya.com','mobile.ximalaya.com') then regexp_extract(url,'(albumId=)(.*?)&',2)
                                when url_host = 'adse.wsa.ximalaya.com' then regexp_extract(url,'(album=)(.*?)&',2) 
                                else null 
                           end as con1,         
                           start_time con5   
                   from  
                         bigflow_origin_sample_base a
                   where pt_days=${day}
                         and url_host in ('mobwsa.ximalaya.com','adse.wsa.ximalaya.com','mobile.ximalaya.com') and (instr(url,'albumId=')>0 or instr(url,'album=')>0);"
      else 
            hive -e"
            insert into tmp_user_con_out_t1
              select       pt_days,
                           device_number,
                           case when url_host in ('mobwsa.ximalaya.com','mobile.ximalaya.com') then regexp_extract(url,'(albumId=)(.*?)&',2)
                                when url_host = 'adse.wsa.ximalaya.com' then regexp_extract(url,'(album=)(.*?)&',2) 
                                else null 
                           end as con1,         
                           start_time con5   
                   from  
                         bigflow_origin_sample_base a
                   where pt_days=${day}
                         and url_host in ('mobwsa.ximalaya.com','adse.wsa.ximalaya.com','mobile.ximalaya.com') and (instr(url,'albumId=')>0 or instr(url,'album=')>0);"
      fi 
done 